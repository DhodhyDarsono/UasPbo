## Keterangan Aplikasi
1. Aplikasi dibuat menggunakan IDE eclipse 2020-12
2. Aplikasi dibuat menggunakan java versi 15.0.1+9-18
3. Aplikasi sudah saya test dan dapat berjalan dengan baik

## Menjalankan Aplikasi
1. Aplikasi dapat di run dengan start pada file `src/view/RentForm.java`

## Konfigurasi Database
1. Konfigurasi database dapat dengan mengedit uri, username, password pada file `src/database/RentDatabase.java`
